# ImageScraper

A simple Python package to scrape images from **Google**, **Bing**, and **Yahoo** search engines.

## Installation

```bash
pip install imagescraper-mavi
